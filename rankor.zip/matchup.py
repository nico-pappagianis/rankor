import os
from datetime import datetime, timedelta
from enum import Enum, IntEnum
from fantasy_data import save, load
import pytz

from data_attributes import MatchupAttrs, TeamAttrs, DATE_FMT, PST
from fantasy_data import FantasyData, get_attribute

SEASON_MATCHUPS_FILE = os.path.join('{league_data_dir}', 'season-matchups.data')
WEEK_MATCHUPS_DIR = os.path.join('{league_data_dir}', 'matchups')
WEEK_MATCHUPS_FILE = 'week-{week}.data'
WEEK_MATCHUPS_QUERY = 'league/{league_key}/scoreboard;week={week}'
TEAM_MATCHUP_QUERY = 'team/{team_key}/matchups'


class Week:
    class Days(IntEnum):
        MONDAY = 0
        TUESDAY = 1
        WEDNESDAY = 2
        THURSDAY = 3
        FRIDAY = 4
        SATURDAY = 5
        SUNDAY = 6

    def __init__(self, week, start_datetime, end_datetime):
        self.week = week
        self.start_datetime = Week._get_week_start_datetime(start_datetime)
        self.end_datetime = Week._get_week_end_datetime(end_datetime)

    @staticmethod
    def _get_week_start_datetime(start_datetime):
        itr_datetime = PST.localize(start_datetime)
        while itr_datetime.weekday() != Week.Days.THURSDAY.value:
            itr_datetime += timedelta(1)
        return itr_datetime.replace(hour=17, minute=20)

    @staticmethod
    def _get_week_end_datetime(end_datetime):
        itr_datetime = PST.localize(end_datetime)
        while itr_datetime.weekday() != Week.Days.TUESDAY.value:
            itr_datetime += timedelta(1)
        return itr_datetime.replace(hour=00, minute=00)


class GameWeek:
    class Status(Enum):
        POST_EVENT = 'postevent'
        PRE_EVENT = 'preevent'
        MID_EVENT = 'midevent'

    def __init__(self, week, start_datetime, end_datetime, matchups=None):
        self.week = Week(week, start_datetime, end_datetime)
        self.matchups = matchups or []

    def add_matchup(self, matchup):
        self.matchups.append(matchup)

    @property
    def status(self):
        now = PST.localize(datetime.now())
        if now < self.week.start_datetime:
            return GameWeek.Status.PRE_EVENT
        elif self.week.start_datetime <= now <= self.week.end_datetime:
            return GameWeek.Status.MID_EVENT
        else:
            return GameWeek.Status.POST_EVENT

    @property
    def in_progress(self):
        return self.status == GameWeek.Status.MID_EVENT


class Matchup:

    def __init__(self, week, team1, team1_points, team2, team2_points):
        self.week = week
        self.team1 = team1
        self.team1_points = team1_points
        self.team2 = team2
        self.team2_points = team2_points

    def __str__(self):
        return 'Week {week} - {team1} {team1_points} vs {team2_points} {team2}'.format(
            week=self.week,
            team1=self.team1, team1_points=self.team1_points,
            team2_points=self.team2_points, team2=self.team2)


class MatchupsData(FantasyData):
    def __init__(self, league, week):
        self.week = week
        self.game_week = None
        super(MatchupsData, self).__init__(
            api_query=WEEK_MATCHUPS_QUERY.format(league_key=league.league_key, week=week))

        matchups_data = self.get_attribute(MatchupAttrs.WEEK_MATCHUPS)
        for matchup_data in matchups_data:

            if not self.game_week:
                start_date = datetime.strptime(get_attribute(matchup_data, MatchupAttrs.WEEK_START_DATE), DATE_FMT)
                end_date = datetime.strptime(get_attribute(matchup_data, MatchupAttrs.WEEK_END_DATE), DATE_FMT)
                self.game_week = GameWeek(week, start_date, end_date)

            teams = get_attribute(matchup_data, MatchupAttrs.MATCHUP_TEAMS)
            team1 = league.teams[int(get_attribute(teams[0], TeamAttrs.TEAM_ID))]
            team1_points = float(get_attribute(teams[0], MatchupAttrs.MATCHUP_TEAM_POINTS))
            team2 = league.teams[int(get_attribute(teams[1], TeamAttrs.TEAM_ID))]
            team2_points = float(get_attribute(teams[1], MatchupAttrs.MATCHUP_TEAM_POINTS))
            self.game_week.add_matchup(Matchup(week, team1, team1_points, team2, team2_points))
